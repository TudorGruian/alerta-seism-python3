# alerta-seism-python3
O librarie pentru Python3 folosiind date XML de la INFP pentru a afla magnitudinea cutremurelor in timp real

